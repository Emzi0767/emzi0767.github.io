var zlib_8h =
[
    [ "zlib_compress", "zlib_8h.html#a5380831b4459130f7780ac9adecb7246", null ],
    [ "zlib_decompress", "zlib_8h.html#adefe9995812d0cd3893aa6a26fe4652c", null ]
];