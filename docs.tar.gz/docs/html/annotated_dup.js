var annotated_dup =
[
    [ "PngImageInfo", "structPngImageInfo.html", "structPngImageInfo" ],
    [ "StegMessage", "structStegMessage.html", "structStegMessage" ]
];