var searchData=
[
  ['bit_5fdepth',['bit_depth',['../structPngImageInfo.html#a588e94d1cd5e47309a1d2ae70295723a',1,'PngImageInfo']]]
];
