var structStegMessage =
[
    [ "contents", "structStegMessage.html#a178d533a98d3eb97982cccdb9e92f7ef", null ],
    [ "cycles", "structStegMessage.html#aa317dea95f6e55f9120909cd0f545d05", null ],
    [ "flags", "structStegMessage.html#a56ed65bdcfc707c2224063b5dbb6f7cc", null ],
    [ "iv", "structStegMessage.html#a24f8440145f8a86b15fb93c3989aaa7a", null ],
    [ "length", "structStegMessage.html#aeb8120ce5e56ec122b3163f045bb122e", null ],
    [ "magic", "structStegMessage.html#a7a7d80979f76b26e3a8022c011e9a6b5", null ],
    [ "salt", "structStegMessage.html#ac1eac6604b26e57b8171c88ef8168120", null ]
];