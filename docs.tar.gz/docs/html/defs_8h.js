var defs_8h =
[
    [ "_UNICODE", "defs_8h.html#a78880e1abcefc90f14185aee93ad0e20", null ],
    [ "UNICODE", "defs_8h.html#a09ecca53f2cd1b8d1c566bedb245e141", null ],
    [ "fail", "defs_8h.html#a413f1a34b314971ba75d786256d1f481", null ],
    [ "mbcslen", "defs_8h.html#a62b4eae016a9606e20ccaaace8af63a5", null ],
    [ "print_usage", "defs_8h.html#aa4c888ac08148b1a8427491238530dc7", null ],
    [ "werrorf", "defs_8h.html#a3576bb6e99817c7dd0145c509313f359", null ],
    [ "PROGRAM_AUTHOR", "defs_8h.html#a0030baa957dd71e646553e08cbfa1560", null ],
    [ "PROGRAM_DESCRIPTION", "defs_8h.html#a3876eb59c0b18d9c47972da848cf76e8", null ],
    [ "PROGRAM_NAME", "defs_8h.html#ad04f1b2d3966f7c0d005b854487a5742", null ],
    [ "PROGRAM_VERSION", "defs_8h.html#a6fcc1b69f64758f9408e398a4666954d", null ]
];