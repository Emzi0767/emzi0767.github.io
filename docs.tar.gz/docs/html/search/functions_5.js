var searchData=
[
  ['png_5fload_5fpixels',['png_load_pixels',['../png_8h.html#a7acaef82eb315c06cff63fa1925bf277',1,'png.c']]],
  ['png_5fsave_5fpixels',['png_save_pixels',['../png_8h.html#a92d35e99fd6e27418f6b2e07f23a5a82',1,'png.c']]],
  ['print_5fusage',['print_usage',['../defs_8h.html#aa4c888ac08148b1a8427491238530dc7',1,'program.c']]]
];
