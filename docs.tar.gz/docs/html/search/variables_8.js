var searchData=
[
  ['magic',['magic',['../structStegMessage.html#a7a7d80979f76b26e3a8022c011e9a6b5',1,'StegMessage']]]
];
