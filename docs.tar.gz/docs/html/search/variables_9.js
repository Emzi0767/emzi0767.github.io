var searchData=
[
  ['program_5fauthor',['PROGRAM_AUTHOR',['../defs_8h.html#a0030baa957dd71e646553e08cbfa1560',1,'program.c']]],
  ['program_5fdescription',['PROGRAM_DESCRIPTION',['../defs_8h.html#a3876eb59c0b18d9c47972da848cf76e8',1,'program.c']]],
  ['program_5fversion',['PROGRAM_VERSION',['../defs_8h.html#a6fcc1b69f64758f9408e398a4666954d',1,'program.c']]]
];
