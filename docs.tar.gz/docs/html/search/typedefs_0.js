var searchData=
[
  ['pngimageinfo',['PngImageInfo',['../png_8h.html#a06d2a306131424d7aaad92f8a74974e9',1,'png.h']]]
];
