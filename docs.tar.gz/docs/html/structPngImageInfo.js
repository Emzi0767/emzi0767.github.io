var structPngImageInfo =
[
    [ "bit_depth", "structPngImageInfo.html#a588e94d1cd5e47309a1d2ae70295723a", null ],
    [ "height", "structPngImageInfo.html#a2319dfd3631f34440a2e32d4c5f50a32", null ],
    [ "width", "structPngImageInfo.html#ab33dd5bd9c4c310dbddfbabc8b6e5815", null ]
];