var searchData=
[
  ['zlib_2eh',['zlib.h',['../zlib_8h.html',1,'']]],
  ['zlib_5fcompress',['zlib_compress',['../zlib_8h.html#a5380831b4459130f7780ac9adecb7246',1,'zlib.c']]],
  ['zlib_5fdecompress',['zlib_decompress',['../zlib_8h.html#adefe9995812d0cd3893aa6a26fe4652c',1,'zlib.c']]]
];
