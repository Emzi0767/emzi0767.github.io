var png_8h =
[
    [ "PngImageInfo", "structPngImageInfo.html", "structPngImageInfo" ],
    [ "PngImageInfo", "png_8h.html#a06d2a306131424d7aaad92f8a74974e9", null ],
    [ "png_load_pixels", "png_8h.html#a7acaef82eb315c06cff63fa1925bf277", null ],
    [ "png_save_pixels", "png_8h.html#a92d35e99fd6e27418f6b2e07f23a5a82", null ]
];