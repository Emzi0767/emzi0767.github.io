var searchData=
[
  ['prm_20project_20_2d_2018l_20semester',['PRM Project - 18L Semester',['../index.html',1,'']]],
  ['png_2eh',['png.h',['../png_8h.html',1,'']]],
  ['png_5fload_5fpixels',['png_load_pixels',['../png_8h.html#a7acaef82eb315c06cff63fa1925bf277',1,'png.c']]],
  ['png_5fsave_5fpixels',['png_save_pixels',['../png_8h.html#a92d35e99fd6e27418f6b2e07f23a5a82',1,'png.c']]],
  ['pngimageinfo',['PngImageInfo',['../structPngImageInfo.html',1,'PngImageInfo'],['../png_8h.html#a06d2a306131424d7aaad92f8a74974e9',1,'PngImageInfo():&#160;png.h']]],
  ['print_5fusage',['print_usage',['../defs_8h.html#aa4c888ac08148b1a8427491238530dc7',1,'program.c']]],
  ['program_5fauthor',['PROGRAM_AUTHOR',['../defs_8h.html#a0030baa957dd71e646553e08cbfa1560',1,'program.c']]],
  ['program_5fdescription',['PROGRAM_DESCRIPTION',['../defs_8h.html#a3876eb59c0b18d9c47972da848cf76e8',1,'program.c']]],
  ['program_5fversion',['PROGRAM_VERSION',['../defs_8h.html#a6fcc1b69f64758f9408e398a4666954d',1,'program.c']]]
];
