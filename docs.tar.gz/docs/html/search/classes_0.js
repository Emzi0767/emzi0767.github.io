var searchData=
[
  ['pngimageinfo',['PngImageInfo',['../structPngImageInfo.html',1,'']]]
];
